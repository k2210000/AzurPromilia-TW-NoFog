@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
set "AZP_GAME=%~1"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0Tool.ps1" -Mode Install
set "AZP_RC=%errorlevel%"
echo.
if not "%AZP_RC%"=="0" (
    echo 操作未成功或已取消。請查看上方訊息。
) else (
    echo 操作完成。
)
echo 結束代碼：%AZP_RC%
pause
exit /b %AZP_RC%
