﻿param(
    [ValidateSet("Backup","Install","Restore")][string]$Mode,
    [string]$GamePath
)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$Host.UI.RawUI.WindowTitle = "藍色星原：旅謠－反虛化簡易工具 v1.0.2"
$names = @(
    'd3svzxgozq953wetzjanua.r',
    's6ppge3l6q1q9htrof7qcq.r',
    'tsn5bfvm7hx6csi1reyrya.r',
    'wf4ksai7xalfafyxycu1g.r'
)
$relative = @(
    '.res\default_package\BundleFiles\d3svzxgozq953wetzjanua.r',
    'StreamingAssets\.res\default_package\s6ppge3l6q1q9htrof7qcq.r',
    'StreamingAssets\.res\default_package\tsn5bfvm7hx6csi1reyrya.r',
    'StreamingAssets\.res\default_package\wf4ksai7xalfafyxycu1g.r'
)
function Hash([string]$p) {
    (Get-FileHash -LiteralPath $p -Algorithm SHA256 -ErrorAction Stop).Hash
}
function Check-Path([string]$p, [bool]$leaf) {
    if ($leaf -and !(Test-Path -LiteralPath $p -PathType Leaf)) {
        throw "缺少檔案：$p"
    }
    $current = $p
    while ($current) {
        if (Test-Path -LiteralPath $current) {
            $item = Get-Item -LiteralPath $current -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "不支援連結或接合點：$current"
            }
        }
        $parent = Split-Path -Path $current -Parent
        if (!$parent -or $parent -eq $current) { break }
        $current = $parent
    }
}
function Confirm([string]$message) {
    Write-Host ""
    Write-Host $message -ForegroundColor Yellow
    Write-Host "請按 Y 確認，或 N 取消；不用按 Enter。" -ForegroundColor Cyan
    # 使用 Windows 主控台單鍵選擇，不依賴中文輸入法或 Read-Host 的行輸入。
    $choicePath = Join-Path $env:SystemRoot 'System32\choice.exe'
    if (!(Test-Path -LiteralPath $choicePath -PathType Leaf)) {
        throw "找不到 Windows choice.exe，無法安全確認；未執行後續操作。"
    }
    if ([Console]::IsInputRedirected) {
        throw "目前不是互動式主控台，無法安全確認。請直接開啟批次檔。"
    }
    & $choicePath /C YN /N /M '[Y/N]'
    $answer = $LASTEXITCODE
    if ($answer -eq 1) { return }
    if ($answer -eq 2 -or $answer -eq 0) { throw "已取消操作。" }
    throw "無法取得確認輸入（choice 結束代碼：$answer）。未執行後續操作。"
}
function Copy-Verified([string]$source,[string]$destination,[string]$expected) {
    Check-Path $source $true
    Check-Path $destination $false
    if ((Hash $source) -ne $expected) { throw "來源檔案驗證失敗：$source" }
    [IO.File]::Copy($source,$destination,$true)
    if ((Hash $destination) -ne $expected) { throw "複製後驗證失敗：$destination" }
}
function New-Snapshot([string]$kind, $hashes, $patchHashes) {
    $folder = Join-Path $backupRoot ((Get-Date -Format "yyyyMMdd_HHmmss_fff") + "_" + [guid]::NewGuid().ToString("N").Substring(0,8) + "_" + $kind)
    [void](New-Item -ItemType Directory -Path $folder)
    for ($i=0; $i -lt $names.Count; $i++) {
        Copy-Verified $targets[$i] (Join-Path $folder $names[$i]) $hashes[$i]
    }
    $state = [ordered]@{
        Kind=$kind; GameData=$data; Original=@($hashes); Patched=@($patchHashes)
    }
    $state | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $folder 'state.json') -Encoding UTF8
    Write-Host "四個檔案已完整備份並驗證：" -ForegroundColor Green
    Write-Host $folder
    return $folder
}
function Replace-Set($sources,$expected,$rollbackSources,$rollbackHashes) {
    # 先檢查所有目的檔案仍為預期的內容，避免使用過期快照。
    for ($i=0; $i -lt $names.Count; $i++) {
        if ((Hash $targets[$i]) -ne $rollbackHashes[$i]) {
            throw "目標檔案已變更，請重新執行工具：$($names[$i])"
        }
        if ((Hash $sources[$i]) -ne $expected[$i] -or
            (Hash $rollbackSources[$i]) -ne $rollbackHashes[$i]) {
            throw "來源或回復檔案驗證失敗。"
        }
    }
    $touched = New-Object 'System.Collections.Generic.List[int]'
    try {
        for ($i=0; $i -lt $names.Count; $i++) {
            $touched.Add($i)
            Copy-Verified $sources[$i] $targets[$i] $expected[$i]
            Write-Host "已完成：$($names[$i])" -ForegroundColor Green
        }
    } catch {
        Write-Host "替換失敗，正在嘗試回復已處理的檔案。" -ForegroundColor Yellow
        $failed = @()
        foreach ($i in $touched) {
            try { Copy-Verified $rollbackSources[$i] $targets[$i] $rollbackHashes[$i] }
            catch { $failed += $names[$i] }
        }
        if ($failed.Count) {
            throw ("自動回復未完全成功，請勿啟動遊戲。請保留備份並使用官方修復。失敗檔案：" + ($failed -join '、'))
        }
        throw "替換未完成，已將處理過的檔案回復至操作前狀態。"
    }
}
$exitCode = 0
try {
    $titles = @{ Backup="僅備份"; Install="安裝反虛化"; Restore="還原原始檔案" }
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host " 藍色星原：旅謠 台服反虛化簡易工具 v1.0.2"
    Write-Host " 操作：$($titles[$Mode])"
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host "非官方測試工具；不連線、不下載、不修改版本清單。"
    Write-Host "請先完全關閉遊戲與啟動器，並確認具有修改授權。"
    if ([string]::IsNullOrWhiteSpace($GamePath) -and ![string]::IsNullOrWhiteSpace($env:AZP_GAME)) {
        $GamePath = $env:AZP_GAME
    }
    if ([string]::IsNullOrWhiteSpace($GamePath)) {
        $GamePath = Read-Host "請輸入包含遊戲資料的根目錄（也可拖曳資料夾）"
    }
    if ([string]::IsNullOrWhiteSpace($GamePath)) { throw "已取消操作。" }
    $GamePath = $GamePath.Trim().Trim('"')
    if (!(Test-Path -LiteralPath $GamePath -PathType Container)) { throw "指定資料夾不存在。" }
    $root = (Get-Item -LiteralPath $GamePath -Force).FullName
    $candidates = @($root,(Join-Path $root 'AzurPromilia_Data'),
        (Join-Path $root 'AzurPromilia_TC_game\AzurPromilia_Data'),
        (Join-Path $root 'AzurPromilia_TC\AzurPromilia_TC_game\AzurPromilia_Data'))
    $found = @($candidates | Where-Object {
        (Split-Path $_ -Leaf) -eq 'AzurPromilia_Data' -and (Test-Path -LiteralPath $_ -PathType Container)
    } | Select-Object -Unique)
    if ($found.Count -ne 1) { throw "找不到唯一的遊戲資料目錄，請輸入正確的台服遊戲根目錄。" }
    $data = (Get-Item -LiteralPath $found[0] -Force).FullName
    Check-Path $data $false
    $targets = @($relative | ForEach-Object { Join-Path $data $_ })
    foreach ($p in $targets) { Check-Path $p $true }
    $backupRoot = Join-Path $data '.tw-deblur-simple-backup'
    Check-Path $backupRoot $false
    # 檢查可辨識的遊戲程序；仍需使用者自行關閉啟動器。
    if (Get-Process | Where-Object { $_.ProcessName -match 'AzurPromilia' }) {
        throw "偵測到遊戲相關程序仍在執行，請完全關閉後再試。"
    }
    Write-Host "已找到四個指定資源檔案。" -ForegroundColor Green
    Write-Host $data
    $current = @($targets | ForEach-Object { Hash $_ })
    if ($Mode -eq 'Restore') {
        if (!(Test-Path -LiteralPath $backupRoot -PathType Container)) { throw "找不到本工具建立的備份。" }
        $latest = Get-ChildItem -LiteralPath $backupRoot -Directory -Force |
            Where-Object { $_.Name -like '*_install' } |
            Sort-Object Name -Descending | Select-Object -First 1
        if (!$latest) { throw "找不到安裝前備份，請勿使用其他版本的備份強制還原。" }
        Check-Path $latest.FullName $false
        $stateFile = Join-Path $latest.FullName 'state.json'
        Check-Path $stateFile $true
        $state = Get-Content -LiteralPath $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.Kind -ne 'install' -or $state.GameData -ne $data -or
            @($state.Original).Count -ne 4 -or @($state.Patched).Count -ne 4) {
            throw "備份資訊與目前遊戲不相符。"
        }
        $sources = @($names | ForEach-Object { Join-Path $latest.FullName $_ })
        for ($i=0;$i -lt 4;$i++) {
            Check-Path $sources[$i] $true
            if ((Hash $sources[$i]) -ne $state.Original[$i]) { throw "備份完整性驗證失敗。" }
            if ($current[$i] -ne $state.Patched[$i]) {
                throw "目前遊戲資源與安裝後紀錄不符，可能已更新或還原。為避免覆蓋新版資源，已停止。"
            }
        }
        Write-Host "已找到最近一次安裝前的備份：" -ForegroundColor Green
        Write-Host $latest.FullName
        Confirm "將還原四個資源檔案；若遊戲已更新，即使檔案仍相同也請取消並使用官方修復。"
        $snapshot = New-Snapshot 'pre_restore' $current $current
        $rollback = @($names | ForEach-Object { Join-Path $snapshot $_ })
        Replace-Set $sources @($state.Original) $rollback $current
        Write-Host "還原完成，備份仍會保留。" -ForegroundColor Green
    } else {
        $payloadRoot = Join-Path $PSScriptRoot 'payload'
        if (!(Test-Path -LiteralPath $payloadRoot -PathType Container)) { throw "缺少替換資源資料夾。" }
        Check-Path $payloadRoot $false
        $payload = @(foreach ($name in $names) {
            $matches = @(Get-ChildItem -LiteralPath $payloadRoot -Recurse -File -Force -Filter $name)
            if ($matches.Count -eq 0) {
                throw "缺少替換資源：$name`n搜尋位置：$payloadRoot`n請完整解壓縮原始工具，勿只取出批次檔。"
            }
            if ($matches.Count -gt 1) {
                $duplicatePaths = ($matches | ForEach-Object { $_.FullName }) -join "`n"
                throw "替換資源有重複：$name（找到 $($matches.Count) 份）`n$duplicatePaths`n請重新解壓縮到空資料夾。"
            }
            Check-Path $matches[0].FullName $true
            if ($matches[0].Length -le 0) { throw "替換資源為空：$name" }
            $matches[0].FullName
        })
        $patch = @($payload | ForEach-Object { Hash $_ })
        for ($i=0;$i -lt 4;$i++) {
            if ($current[$i] -eq $patch[$i]) {
                throw "偵測到至少一個檔案已與替換資源相同。請先還原或使用官方修復，避免把修改檔當成原始備份。"
            }
        }
        Write-Host "四個替換資源已找到；將使用本機雜湊驗證複製結果。"
        Write-Host "未驗證替換資源的官方來源、原始版本或跨版本相容性。" -ForegroundColor Yellow
        Write-Host "請確認目前遊戲資源未經其他補丁修改，且替換資源來自可信的原版補丁。"
        if ($Mode -eq 'Backup') {
            Confirm "僅建立備份，不替換任何遊戲資源。"
            if (!(Test-Path -LiteralPath $backupRoot)) { [void](New-Item -ItemType Directory -Path $backupRoot) }
            $null = New-Snapshot 'manual' $current $patch
            Write-Host "備份完成，遊戲資源未修改。" -ForegroundColor Green
        } else {
            Confirm "本工具不強制檢查版本清單。直接覆蓋可能造成資源錯誤、閃退或帳號風險；確認接受後將先備份再安裝。"
            if (!(Test-Path -LiteralPath $backupRoot)) { [void](New-Item -ItemType Directory -Path $backupRoot) }
            $snapshot = New-Snapshot 'install' $current $patch
            $rollback = @($names | ForEach-Object { Join-Path $snapshot $_ })
            Replace-Set $payload $patch $rollback $current
            Write-Host "安裝完成。僅通過檔案複製驗證，尚未驗證遊戲實際相容性。" -ForegroundColor Green
        }
    }
} catch {
    $exitCode = 1
    Write-Host "操作未完成：" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
}
Write-Host ""
exit $exitCode
